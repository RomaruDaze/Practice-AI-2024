async function querySPARQL(searchInput, searchType, minPrice, maxPrice) {
    let query;
    if (searchType === 'productName') {
        query = `
            PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
            PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
            PREFIX owl: <http://www.w3.org/2002/07/owl#>
            PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>
            PREFIX owl1: <file:/Users/rogermarvin/Desktop/Coding/AI/14-15.owl#>

            SELECT DISTINCT ?individual ?property ?value
            WHERE {
                ?individual owl1:hasBrand ?brand .
                ?individual ?property ?value .
                
                BIND(STRAFTER(STR(?individual), "#") AS ?individualName)
                FILTER(REGEX(?individualName, "${searchInput}", "i"))
                FILTER(?property != rdf:type)
                
                ?individual owl1:hasPrice ?price .
                BIND(xsd:integer(REPLACE(?price, "[^0-9]", "")) AS ?numericPrice)
                FILTER(?numericPrice >= ${minPrice} && ?numericPrice <= ${maxPrice})

                OPTIONAL {
                    ?brand rdfs:label ?brandName .
                }
            }
            ORDER BY ?individual ?property
        `;
    } else if (searchType === 'category') {
        query = `
        PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
        PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
        PREFIX owl: <http://www.w3.org/2002/07/owl#>
        PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>
        PREFIX owl1: <file:/Users/rogermarvin/Desktop/Coding/AI/14-15.owl#>

        SELECT DISTINCT ?individual ?property ?value
        WHERE {
            ?individual rdf:type ?category .
            ?category rdfs:label ?categoryLabel .
            FILTER(CONTAINS(LCASE(STR(?categoryLabel)), LCASE("${searchInput}")))

            ?individual owl1:hasBrand ?brand .
            ?individual ?property ?value .
            FILTER(?property != rdf:type)

            ?individual owl1:hasPrice ?price .
            BIND(xsd:integer(REPLACE(?price, "[^0-9]", "")) AS ?numericPrice)
            FILTER(?numericPrice >= ${minPrice} && ?numericPrice <= ${maxPrice})

            OPTIONAL {
                ?brand rdfs:label ?brandName .
            }
        }
        ORDER BY ?individual ?property
        `;
    }

    console.log("SPARQL Query:", query);

    const encodedQuery = encodeURIComponent(query);
    const targetUrl = `http://localhost:8890/sparql?query=${encodedQuery}&format=json`;

    try {
        const response = await fetch(targetUrl, {
            headers: {
                'Accept': 'application/sparql-results+json'
            }
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        displayResults(data);
    } catch (error) {
        console.error('Error querying SPARQL endpoint:', error);
        const resultsDiv = document.getElementById('results');
        resultsDiv.innerHTML = `Error: ${error.message}`;
    }
}

function displayResults(data) {
    const resultsDiv = document.getElementById('results');
    resultsDiv.innerHTML = '';

    const propertyLabels = {
        'hasBrand': 'Brand',
        'hasBuildVolume': 'Build Volume',
        'hasLayerResolution': 'Layer Resolution',
        'hasMaterialCompatibility': 'Material Compatibility',
        'hasModel': 'Model',
        'hasPrice': 'Price',
        'hasTechnology': 'Technology',
        'hasWeight': 'Weight',
        'hasCuttingArea': 'Cutting Area',
        'hasLaserPower': 'Laser Power',
        'hasPrintArea': 'Print Area',
        'hasPrintResolution': 'Print Resolution',
        'hasSpindlePower': 'Spindle Power',
        'hasWorkArea': 'Work Area',
        'hasPower': 'Power',
        'hasSpeed': 'Speed',
        'hasImage': 'Image',
        'hasLink': 'Link',
        'hasVoltage': 'Voltage',
        'hasWattage': 'Wattage'
    };

    const propertyClasses = {
        'hasBrand': 'label-bg-brand',
        'hasPrice': 'label-bg-price',
        'hasWeight': 'label-bg-weight',
        'hasBuildVolume': 'label-bg-build-volume',
        'hasLayerResolution': 'label-bg-layer-resolution',
        'hasMaterialCompatibility': 'label-bg-material-compatibility',
        'hasModel': 'label-bg-model',
        'hasTechnology': 'label-bg-technology',
        'hasCuttingArea': 'label-bg-cutting-area',
        'hasLaserPower': 'label-bg-laser-power',
        'hasPrintArea': 'label-bg-print-area',
        'hasPrintResolution': 'label-bg-print-resolution',
        'hasSpindlePower': 'label-bg-spindle-power',
        'hasWorkArea': 'label-bg-work-area',
        'hasPower': 'label-bg-power',
        'hasSpeed': 'label-bg-speed',
        'hasVoltage': 'label-bg-voltage',
        'hasWattage': 'label-bg-wattage'
    };

    const individuals = {};

    data.results.bindings.forEach(row => {
        const individualFullUri = row.individual.value;
        const individual = individualFullUri.split('#').pop(); // Extract the name after the #
        const property = row.property.value.split('#').pop();
        let value = row.value.value;
        const label = propertyLabels[property] || property;

        if (!individuals[individual]) {
            individuals[individual] = {};
        }

        if (!individuals[individual][property]) {
            if (property === 'hasImage' || property === 'hasLink') {
                try {
                    new URL(value);
                    individuals[individual][property] = { property, label, value };
                } catch (e) {
                }
            } else {
                // Format specific properties
                if (property === 'hasPrice') {
                    value = `${value} 円`;
                } else if (property === 'hasWeight') {
                    value = `${value} kg`;
                } else if (property === 'hasBuildVolume') {
                    value = `${value} mm³`;
                } else if (property === 'hasPower') {
                    value = `${value} amp`;
                } else if (property === 'hasLayerResolution') {
                    value = `${value} µm`;
                } else if (property === 'hasWorkArea') {
                    value = `${value} mm²`;
                } else if (property === 'hasSpindlePower') {
                    value = `${value} W`;
                } else if (property === 'hasLaserPower') {
                    value = `${value} W`;
                } else if (property === 'hasCuttingArea') {
                    value = `${value} mm²`;
                } else if (property === 'hasVoltage') {
                    value = `${value} V`;
                } else if (property === 'hasWattage') {
                    value = `${value} W`;
                } else if (property === 'hasPrintResolution') {
                    value = `${value} µm`;
                } else if (property === 'hasSpeed') {
                    value = `${value} rpm`;
                } else if (property === 'hasBrand') {
                    value = row.brandName ? row.brandName.value : value.split('#').pop();
                }
                individuals[individual][property] = { property, label, value };
            }
        }
    });

    Object.keys(individuals).forEach(individualFullUri => {
        const individual = individualFullUri.split('#').pop(); // Extract the name after the #
        const individualDiv = document.createElement('div');
        individualDiv.className = 'individual';

        // Add a title with the individual name
        const titleDiv = document.createElement('h2');
        titleDiv.textContent = individual.replace(/_/g, ' '); // Replace underscores with spaces
        individualDiv.appendChild(titleDiv);

        const descriptionDiv = document.createElement('div');
        const imageDiv = document.createElement('div');
        const linkDiv = document.createElement('div');

        Object.values(individuals[individualFullUri]).forEach(({ property, label, value }) => {
            const resultItem = document.createElement('div');

            if (property === 'hasImage') {
                const img = document.createElement('img');
                img.src = value;
                img.alt = label;
                img.className = 'result-image';
                imageDiv.appendChild(img);
            } else if (property === 'hasLink') {
                const link = document.createElement('a');
                link.href = value;
                link.textContent = 'More Info';
                link.className = 'result-link';
                link.target = '_blank';
                linkDiv.appendChild(link);
            } else {
                const labelSpan = document.createElement('span');
                labelSpan.className = propertyClasses[property] || 'label-bg';
                labelSpan.textContent = `${label} :`;

                resultItem.appendChild(labelSpan);
                resultItem.append(` ${value}`);
                descriptionDiv.appendChild(resultItem);
            }
        });

        individualDiv.appendChild(descriptionDiv);
        individualDiv.appendChild(imageDiv);
        individualDiv.appendChild(linkDiv);
        resultsDiv.appendChild(individualDiv);
    });
}

function handleInput() {
    const searchInput = document.getElementById('individualInput').value.replace(/ /g, '_');
    const searchType = document.getElementById('searchType').value;
    const minPrice = parseInt(document.getElementById('minPrice').value);
    const maxPrice = parseInt(document.getElementById('maxPrice').value);
    querySPARQL(searchInput, searchType, minPrice, maxPrice);
}

document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('individualInput').addEventListener('input', handleInput);
    document.getElementById('searchType').addEventListener('change', handleInput);
    document.getElementById('minPrice').addEventListener('input', handleInput);
    document.getElementById('maxPrice').addEventListener('input', handleInput);

    // Initial search
    handleInput();
});