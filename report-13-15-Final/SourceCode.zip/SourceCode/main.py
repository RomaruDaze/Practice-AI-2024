import os
from selenium import webdriver
from selenium.webdriver.chrome.service import Service

PATH = "./cd/chromedriver"
service = Service(PATH)

chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument("--disable-web-security")
chrome_options.add_argument("--disable-site-isolation-trials")
chrome_options.add_argument("--start-fullscreen") 

driver = webdriver.Chrome(service=service, options=chrome_options)
driver.get("file:///Users/rogermarvin/Desktop/Coding/AI/AI%E6%9C%80%E7%B5%82%E8%AA%B2%E9%A1%8C/index.html")

input("Press Enter to close the browser...")
driver.quit()